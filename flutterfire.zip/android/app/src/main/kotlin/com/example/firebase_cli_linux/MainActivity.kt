package com.example.firebase_cli_linux

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
