import 'package:cloud_firestore/cloud_firestore.dart';

import 'home_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomeCubit extends Cubit<HomeStates>{
  HomeCubit():super(HomeInitial());

  static HomeCubit get(context)=>BlocProvider.of(context);

  getProducts() async{
    try{
      var data = await FirebaseFirestore.instance.collection('products').get();
      for (var element in data.docs) {
        print('===============${element.data()}================');
      }
    }
    catch(err){
      print(err);
    }
  }
}